import React, { useState, useCallback } from 'react';

interface ImageInputProps {
  onImageSelected: (base64: string | null) => void;
  isLoading: boolean;
}

const ImageInput: React.FC<ImageInputProps> = ({ onImageSelected, isLoading }) => {
  const [previewUrl, setPreviewUrl] = useState<string | null>(null);

  const handleFileChange = useCallback((event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onloadend = () => {
        const base64String = (reader.result as string).split(',')[1]; // Get only the base64 part
        setPreviewUrl(reader.result as string);
        onImageSelected(base64String);
      };
      reader.readAsDataURL(file);
    } else {
      setPreviewUrl(null);
      onImageSelected(null);
    }
  }, [onImageSelected]);

  return (
    <div className="relative p-6 bg-white rounded-xl shadow-lg border border-gray-200 w-full max-w-lg mx-auto transition-all duration-300 transform hover:scale-[1.01]">
      <label
        htmlFor="image-upload"
        className={`flex flex-col items-center justify-center w-full h-48 border-2 border-dashed rounded-lg cursor-pointer bg-gray-50 hover:bg-gray-100 transition-colors duration-200 ${
          previewUrl ? 'border-indigo-500' : 'border-gray-300'
        }`}
      >
        {previewUrl ? (
          <img src={previewUrl} alt="Preview" className="max-h-44 object-contain rounded-md" />
        ) : (
          <div className="flex flex-col items-center justify-center pt-5 pb-6">
            <svg
              className="w-10 h-10 mb-3 text-gray-400"
              fill="none"
              stroke="currentColor"
              viewBox="0 0 24 24"
              xmlns="http://www.w3.org/2000/svg"
            >
              <path
                strokeLinecap="round"
                strokeLinejoin="round"
                strokeWidth="2"
                d="M7 16a4 4 0 01-.88-7.903A5 5 0 1115.9 6L16 6a5 5 0 011 9.9M15 13l-3-3m0 0l-3 3m3-3v12"
              ></path>
            </svg>
            <p className="mb-2 text-sm text-gray-500 text-center">
              <span className="font-semibold">Click to upload</span> or drag and drop
            </p>
            <p className="text-xs text-gray-500">PNG or JPG (Max 5MB)</p>
          </div>
        )}
        <input
          id="image-upload"
          type="file"
          className="hidden"
          accept="image/png, image/jpeg"
          onChange={handleFileChange}
          disabled={isLoading}
        />
      </label>
      <div className="mt-4 text-center">
        {previewUrl && !isLoading && (
          <button
            onClick={() => {
              setPreviewUrl(null);
              onImageSelected(null);
            }}
            className="mt-2 text-sm text-red-600 hover:text-red-800 transition-colors duration-200"
            disabled={isLoading}
          >
            Clear Image
          </button>
        )}
      </div>
    </div>
  );
};

export default ImageInput;