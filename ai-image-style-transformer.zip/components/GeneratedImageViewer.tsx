import React from 'react';
import { GeneratedImage } from '../types';

interface GeneratedImageViewerProps {
  images: GeneratedImage[];
}

const GeneratedImageViewer: React.FC<GeneratedImageViewerProps> = ({ images }) => {
  if (images.length === 0) {
    return null;
  }

  const handleDownload = (base64Data: string, style: string) => {
    const link = document.createElement('a');
    link.href = `data:image/png;base64,${base64Data}`;
    link.download = `${style.toLowerCase().replace(/\s/g, '-')}-image-${Date.now()}.png`;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  return (
    <div className="grid grid-cols-1 md:grid-cols-3 gap-8 mt-12 w-full max-w-5xl">
      {images.map((img) => (
        <div
          key={img.id}
          className="flex flex-col items-center bg-white rounded-xl shadow-xl overflow-hidden transform transition-transform duration-300 hover:scale-[1.02]"
        >
          <img
            src={`data:image/png;base64,${img.base64Data}`}
            alt={img.description}
            className="w-full h-auto object-cover border-b-2 border-indigo-200"
            style={{ aspectRatio: '1/1' }}
          />
          <div className="p-4 text-center w-full">
            <h3 className="text-lg font-semibold text-gray-800">{img.description.split(':')[0]}</h3>
            <p className="text-sm text-gray-600 mt-1">{img.description.split(':')[1]?.trim()}</p>
            <button
              onClick={() => handleDownload(img.base64Data, img.style)}
              className="bg-indigo-500 hover:bg-indigo-600 text-white font-semibold py-2 px-4 rounded-full text-sm mt-3 flex items-center justify-center gap-2 transition-all duration-200 w-full"
            >
              <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={2} stroke="currentColor" className="w-4 h-4">
                <path strokeLinecap="round" strokeLinejoin="round" d="M3 16.5v2.25A2.25 2.25 0 005.25 21h13.5A2.25 2.25 0 0021 18.75V16.5M16.5 12L12 16.5m0 0L7.5 12m4.5 4.5V3" />
              </svg>
              Download PNG
            </button>
          </div>
        </div>
      ))}
    </div>
  );
};

export default GeneratedImageViewer;