import { GoogleGenAI, Modality, GenerateContentResponse, VideoGenerationOperation } from "@google/genai";
import { GEMINI_IMAGE_MODEL, VEO_VIDEO_MODEL } from '../constants';
import { ApiError } from '../types';

/**
 * Initializes GoogleGenAI, ensuring the API key is retrieved freshly.
 * @returns An instance of GoogleGenAI.
 * @throws {Error} if API_KEY is not defined.
 */
function getGenAIInstance(): GoogleGenAI {
  if (!process.env.API_KEY) {
    throw new Error('API_KEY is not defined. Please ensure it is set in your environment.');
  }
  return new GoogleGenAI({ apiKey: process.env.API_KEY });
}

/**
 * Helper to create a structured ApiError object from various error types.
 * @param error The raw error caught.
 * @param isVideoService If the error originated from the video service.
 * @returns A structured ApiError object.
 */
function createApiError(error: any, isVideoService: boolean = false): ApiError {
  console.error(`Error in ${isVideoService ? 'video' : 'image'} service:`, error);
  let errorMessage = 'Failed to communicate with AI service.';
  let errorDetails: string | undefined = undefined;
  let errorCode: number | undefined;

  // Check for HTTP response errors
  if (error.response) {
    errorCode = error.response.status;
    errorMessage = `API Error ${errorCode}: ${error.response.statusText || 'Unknown Error'}`;
    errorDetails = error.response.statusText || 'Unknown Error';

    if (error.response.data && error.response.data.error) {
      // More specific error message from the API response body
      errorMessage = error.response.data.error.message || errorMessage;
      if (error.response.data.error.code) {
        errorCode = error.response.data.error.code; // Use specific error code from body if available
      }
      if (error.response.data.error.details) {
        errorDetails = JSON.stringify(error.response.data.error.details, null, 2);
      } else if (error.response.data.message) { // Fallback if no structured 'error' field
        errorDetails = error.response.data.message;
      }
    } else if (error.response.data) { // If there's data but not in expected 'error' structure
      errorDetails = JSON.stringify(error.response.data, null, 2);
    }
  } else if (error instanceof Error) {
    // Standard JavaScript Error
    errorMessage = error.message;
    errorDetails = error.stack;
  } else if (typeof error === 'string') {
    // Simple string error
    errorMessage = error;
  } else if (typeof error === 'object' && error !== null && error.message) {
    // Object with a message property
    errorMessage = error.message;
    if (error.details) errorDetails = error.details;
    if (error.code) errorCode = error.code;
  }

  // Special handling for Quota Exceeded errors (429 status or message content)
  if (errorCode === 429 || (errorMessage.includes("quota") && errorMessage.includes("exceeded"))) {
    errorMessage = "Quota Exceeded: You have exceeded your API usage limits.";
    errorDetails = (errorDetails ? errorDetails + "\n\n" : "") + "Please check your plan and billing details, or try again later. For more information, visit https://ai.google.dev/gemini-api/docs/rate-limits";
  }

  // Specific handling for "API key expired" (400 status with specific message/reason)
  if (errorCode === 400 && (errorMessage.includes("API key expired") || errorMessage.includes("API_KEY_INVALID"))) {
    errorMessage = "API Key Expired: Your Google Gemini API key has expired or is invalid.";
    errorDetails = (errorDetails ? errorDetails + "\n\n" : "") + "Please generate and select a new API key in the 'API Key Management' section, and ensure your billing details are up to date. For more information, visit https://ai.google.dev/gemini-api/docs/billing";
  }

  // Specific handling for "Requested entity was not found." (API key issue for Veo, or model not found for images)
  // This covers 404 for model not found and potential API key issues if the key is completely unrecognized
  if (errorCode === 404 && errorMessage.includes("not found")) {
    if (isVideoService) {
        errorMessage = "Video Model or API Key Not Found/Invalid.";
        errorDetails = (errorDetails ? errorDetails + "\n\n" : "") + "Please ensure you have selected a valid API Key for Veo video generation in the 'API Key Management' section, and that the Veo model is available.";
    } else if (errorMessage.includes("models/gemini-2.5-flash-preview-image")) { // Specific check for the old model name
        // This error indicates that despite the constant being updated in code, the runtime is still using the old model name.
        errorMessage = "Image Model Not Found (Possible Outdated Cache): The API reported that model 'gemini-2.5-flash-preview-image' is unavailable.";
        errorDetails = (errorDetails ? errorDetails + "\n\n" : "") + `The application is configured to use the correct model '${GEMINI_IMAGE_MODEL}'. This error likely means your browser cache or deployment environment is still running an outdated version of the code. Please try clearing your browser cache and reloading the application. If the issue persists, contact support.`;
    } else {
        errorMessage = "Resource Not Found: The requested AI resource could not be found.";
        errorDetails = (errorDetails ? errorDetails + "\n\n" : "") + "This could be due to an incorrect model name or region availability. Please check the documentation or try again later.";
    }
  }


  return {
    message: errorMessage,
    details: errorDetails,
    code: errorCode,
  };
}


/**
 * Generates a styled image using the Gemini API.
 * @param base64Image The base64 encoded string of the input image.
 * @param prompt The text prompt describing the desired style.
 * @returns A Promise that resolves to the base64 encoded string of the generated image.
 * @throws {ApiError} If the API call fails or the response is invalid.
 */
export async function generateStyledImage(
  base64Image: string,
  prompt: string,
): Promise<string> {
  const ai = getGenAIInstance();

  try {
    const imagePart = {
      inlineData: {
        mimeType: 'image/png', // Assuming input is PNG, can be dynamically determined if needed
        data: base64Image,
      },
    };
    const textPart = {
      text: prompt,
    };

    const response: GenerateContentResponse = await ai.models.generateContent({
      model: GEMINI_IMAGE_MODEL,
      contents: { parts: [imagePart, textPart] },
      config: {
        responseModalities: [Modality.IMAGE],
      },
    });

    const generatedImagePart = response.candidates?.[0]?.content?.parts?.[0];

    if (generatedImagePart?.inlineData?.data) {
      return generatedImagePart.inlineData.data;
    } else {
      throw createApiError({
        message: 'No image data received from AI. Please try again.',
        details: JSON.stringify(response),
      });
    }
  } catch (error: any) {
    throw createApiError(error);
  }
}

/**
 * Generates a video from an image using the Veo 3.1 model.
 * Handles API key selection and polling for operation completion.
 * @param base64Image The base64 encoded string of the input image.
 * @param prompt The text prompt for video generation.
 * @returns A Promise that resolves to the URL of the generated video.
 * @throws {ApiError} If the API call fails, API key is not selected, or response is invalid.
 */
export async function generateVideoFromImage(
  base64Image: string,
  prompt: string,
): Promise<string> {
  // App.tsx now handles proactive API key selection.
  // getGenAIInstance() will throw if API_KEY is missing, which App.tsx will catch.
  const ai = getGenAIInstance();

  try {
    let operation: VideoGenerationOperation = await ai.models.generateVideos({
      model: VEO_VIDEO_MODEL,
      prompt: prompt,
      image: {
        imageBytes: base64Image,
        mimeType: 'image/png', // Assuming input is PNG
      },
      config: {
        numberOfVideos: 1,
        resolution: '720p',
        aspectRatio: '16:9',
      },
    });

    while (!operation.done) {
      await new Promise(resolve => setTimeout(resolve, 10000)); // Poll every 10 seconds
      operation = await ai.operations.getVideosOperation({ operation: operation });
    }

    const downloadLink = operation.response?.generatedVideos?.[0]?.video?.uri;

    if (downloadLink) {
      // The response.body contains the MP4 bytes. You must append an API key when fetching from the download link.
      // We will return the URI as it's directly usable with the appended API key.
      return `${downloadLink}&key=${process.env.API_KEY}`;
    } else {
      throw createApiError({
        message: 'No video URI received from AI. Please try again.',
        details: JSON.stringify(operation),
      }, true);
    }
  } catch (error: any) {
    throw createApiError(error, true); // Pass true to indicate video service error
  }
}