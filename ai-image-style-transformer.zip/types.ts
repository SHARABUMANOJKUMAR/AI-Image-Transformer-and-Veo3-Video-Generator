
export type ImageStyle = 'luxury' | 'streetwear' | 'formal';

export interface GeneratedImage {
  id: string;
  style: ImageStyle;
  base64Data: string;
  description: string;
}

export interface GeneratedVideo {
  id: string;
  videoUrl: string;
  prompt: string;
}

export interface ApiError {
  message: string;
  details?: string;
  code?: number;
}

// Define the AIStudio interface for window.aistudio to centralize its type definition.
export interface AIStudio {
  hasSelectedApiKey: () => Promise<boolean>;
  openSelectKey: () => Promise<void>;
}