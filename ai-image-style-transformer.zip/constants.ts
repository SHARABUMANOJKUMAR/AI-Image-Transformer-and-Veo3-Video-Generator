
import { ImageStyle } from './types';

export const GEMINI_IMAGE_MODEL = 'gemini-2.5-flash-image'; // Corrected model name
export const VEO_VIDEO_MODEL = 'veo-3.1-fast-generate-preview';
export const DEFAULT_VIDEO_PROMPT = "A short, dynamic video of the person from the image, performing a stylish action in a vibrant, cinematic setting. The video should have a fashion-forward aesthetic.";


export const PROMPTS: Record<ImageStyle, string> = {
  luxury: `Keep the person's face, features, and body shape exactly the same. Only change the outfit, accessories, and background. Generate a high-quality, realistic, studio-quality PNG image (1024x1024) of the person wearing a luxurious, designer outfit with premium materials, elegant jewelry, and stylish designer sunglasses. The background should be clean, minimalist, and indicate a high-end setting with natural, soft lighting.`,
  streetwear: `Keep the person's face, features, and body shape exactly the same. Only change the outfit, accessories, and background. Generate a high-quality, realistic, studio-quality PNG image (1024x1024) of the person dressed in trendy streetwear, including a modern jacket, stylish sneakers, and subtle urban accessories. The background should be a clean, urban-inspired setting or a simple solid color. Use natural, dynamic lighting.`,
  formal: `Keep the person's face, features, and body shape exactly the same. Only change the outfit, accessories, and background. Generate a high-quality, realistic, studio-quality PNG image (1024x1024) of the person in a sophisticated business suit (e.g., tailored blazer, crisp shirt, tie/blouse). The background should be a clean, professional office setting or a solid, neutral color, well-lit with natural, soft professional lighting.`,
};

export const STYLE_DESCRIPTIONS: Record<ImageStyle, string> = {
  luxury: 'Luxury Style: Rich outfit with designer sunglasses and a premium look.',
  streetwear: 'Trendy Streetwear: Casual, modern vibe.',
  formal: 'Formal Professional: Business suit and clean background.',
};
