import React, { useState, useCallback, useEffect } from 'react';
import ImageInput from './components/ImageInput';
import GeneratedImageViewer from './components/GeneratedImageViewer';
import { generateStyledImage, generateVideoFromImage } from './services/geminiService';
import { GeneratedImage, ImageStyle, ApiError, GeneratedVideo, AIStudio } from './types';
import { PROMPTS, STYLE_DESCRIPTIONS, DEFAULT_VIDEO_PROMPT } from './constants';

// The `declare global` block is removed to prevent "Subsequent property declarations" errors.
// As per coding guidelines, assume `window.aistudio` is pre-configured and accessible.
// We will use a type assertion when accessing `window.aistudio` to ensure type safety.

const App: React.FC = () => {
  const [uploadedImageBase64, setUploadedImageBase64] = useState<string | null>(null);
  const [generatedImages, setGeneratedImages] = useState<GeneratedImage[]>([]);
  const [generatedVideo, setGeneratedVideo] = useState<GeneratedVideo | null>(null);
  const [isLoadingImages, setIsLoadingImages] = useState<boolean>(false);
  const [isLoadingVideo, setIsLoadingVideo] = useState<boolean>(false);
  const [error, setError] = useState<ApiError | null>(null);
  const [videoError, setVideoError] = useState<ApiError | null>(null);
  const [apiKeySelected, setApiKeySelected] = useState<boolean | null>(null); // null: checking, true: selected, false: not selected

  // Effect to check API key status on mount
  useEffect(() => {
    const checkKeyStatus = async () => {
      // Access `window.aistudio` using a type assertion to `AIStudio | undefined`.
      // This provides type safety without requiring a `declare global` block,
      // which can cause conflicts if `window.aistudio` is already globally defined.
      const aistudio = (window as any).aistudio as AIStudio | undefined;

      if (aistudio && typeof aistudio.hasSelectedApiKey === 'function') {
        try {
          const hasKey = await aistudio.hasSelectedApiKey();
          setApiKeySelected(hasKey);
        } catch (err) {
          console.error("Failed to check API Key status:", err);
          setApiKeySelected(false); // Assume not selected if check fails
        }
      } else {
        // If window.aistudio is not available, assume API key is handled externally (e.g., via process.env)
        // and thus "selected" in this context for non-interactive key management.
        setApiKeySelected(true);
        console.warn("window.aistudio API key selection functions not available. Assuming API key is provided via environment.");
      }
    };
    checkKeyStatus();
  }, []);

  const handleImageSelected = useCallback((base64: string | null) => {
    setUploadedImageBase64(base64);
    setGeneratedImages([]); // Clear previous results when a new image is selected
    setGeneratedVideo(null); // Clear previous video
    setError(null);
    setVideoError(null);
  }, []);

  const handleGenerateImages = useCallback(async () => {
    if (!uploadedImageBase64) {
      setError({ message: 'Please upload an image first.' });
      return;
    }

    setIsLoadingImages(true);
    setGeneratedImages([]);
    setError(null);

    const styles: ImageStyle[] = ['luxury', 'streetwear', 'formal'];
    const generationPromises = styles.map(async (style) => {
      try {
        const imageBase64 = await generateStyledImage(uploadedImageBase64, PROMPTS[style]);
        return {
          id: `${style}-${Date.now()}`,
          style,
          base64Data: imageBase64,
          description: STYLE_DESCRIPTIONS[style],
        };
      } catch (err: any) {
        // err here is already an ApiError object because generateStyledImage throws ApiError
        console.error(`Error generating ${style} image:`, err.message, err.details); // Improved logging
        throw err; // Re-throw the ApiError so Promise.allSettled catches it
      }
    });

    try {
      const results = await Promise.allSettled(generationPromises);
      const successfulGenerations: GeneratedImage[] = [];
      const failedReasons: ApiError[] = []; // This will contain ApiError objects

      results.forEach((result) => {
        if (result.status === 'fulfilled') {
          successfulGenerations.push(result.value);
        } else {
          // result.reason is guaranteed to be the ApiError object we threw
          failedReasons.push(result.reason as ApiError);
        }
      });

      if (successfulGenerations.length > 0) {
        setGeneratedImages(successfulGenerations);
      }

      if (failedReasons.length > 0) {
        // Prioritize specific errors if they are common among failures
        const quotaError = failedReasons.find(reason => reason.code === 429 || reason.message?.includes("Quota Exceeded"));
        const apiKeyExpiredError = failedReasons.find(reason => reason.code === 400 && reason.message?.includes("API Key Expired"));
        const modelNotFoundError = failedReasons.find(reason => reason.code === 404 && reason.message?.includes("Image Model Not Found"));

        if (quotaError) {
          setError(quotaError);
        } else if (apiKeyExpiredError) {
          setError(apiKeyExpiredError);
        } else if (modelNotFoundError) {
          setError(modelNotFoundError);
        }
        else {
          // Otherwise, show a generic failure with details from the first failure
          const firstFailure = failedReasons[0];
          setError({
            message: firstFailure.message || 'Some or all images failed to generate.',
            details: firstFailure.details || 'Check your network and API key. If the problem persists, the AI model might be experiencing issues.',
            code: firstFailure.code,
          });
        }
      } else if (successfulGenerations.length === 0) {
        // If no images generated and no specific errors caught, it's a general failure
        setError({
          message: 'No images were generated. Please try again.',
          details: 'An unknown issue prevented image generation. Check your internet connection.',
        });
      }

    } catch (err: any) {
      // This catch block might be hit if Promise.allSettled itself throws, which is rare.
      const apiError: ApiError = err as ApiError;
      setError({ message: apiError.message || 'An unexpected error occurred during image generation.', details: apiError.details });
    } finally {
      setIsLoadingImages(false);
    }
  }, [uploadedImageBase64]);

  const handleGenerateVideo = useCallback(async () => {
    if (!uploadedImageBase64) {
      setVideoError({ message: 'Please upload an image first to generate a video.' });
      return;
    }

    // Proactively check if API key is selected via the dedicated management.
    if (!apiKeySelected) {
      setVideoError({
        message: 'API Key not selected.',
        details: 'Please select an API Key using the "API Key Management" section before generating video.',
        code: 404, // Use 404 to signify key issue
      });
      return;
    }

    setIsLoadingVideo(true);
    setGeneratedVideo(null);
    setVideoError(null);

    try {
      const videoUrl = await generateVideoFromImage(uploadedImageBase64, DEFAULT_VIDEO_PROMPT);
      setGeneratedVideo({
        id: `video-${Date.now()}`,
        videoUrl: videoUrl,
        prompt: DEFAULT_VIDEO_PROMPT,
      });
    } catch (err: any) {
      const apiError: ApiError = err as ApiError;
      setVideoError(apiError);
    } finally {
      setIsLoadingVideo(false);
    }
  }, [uploadedImageBase64, apiKeySelected]);

  const handleManageApiKey = useCallback(async () => {
    // Access `window.aistudio` using a type assertion.
    const aistudio = (window as any).aistudio as AIStudio | undefined;
    if (aistudio && typeof aistudio.openSelectKey === 'function') {
      try {
        await aistudio.openSelectKey();
        const hasKey = await aistudio.hasSelectedApiKey();
        setApiKeySelected(hasKey);
        // Clear any video or image errors related to API key after user attempts to fix it
        // Check if the error is related to API key (400 for expired, 404 for not selected/invalid key)
        if (videoError?.code === 404 && videoError?.message?.includes("API Key not selected")) {
          setVideoError(null);
        }
        if (videoError?.code === 404 && videoError?.message?.includes("Video Model or API Key Not Found/Invalid")) {
          setVideoError(null);
        }
        if (error?.code === 400 && error?.message?.includes("API Key Expired")) {
          setError(null);
        }
      } catch (error: any) {
        console.error("API Key selection was cancelled or failed:", error);
        setApiKeySelected(false); // Indicate failure
        // Provide a clearer error if the selection dialog itself fails or is cancelled
        setVideoError({ // Display this in videoError section for consistency
          message: "API Key selection was cancelled or failed.",
          details: error.message || "Please ensure you select a valid API key.",
          code: error.code || undefined,
        });
      }
    } else {
      alert('API key selection interface is not available in this environment.');
    }
  }, [videoError, error]); // Dependencies on videoError and error to clear them if fixed


  return (
    <div className="flex flex-col items-center justify-center min-h-screen p-4 bg-gradient-to-br from-blue-600 via-indigo-700 to-purple-800 text-white font-sans">
      <div className="w-full max-w-6xl p-8 bg-white/10 backdrop-blur-md rounded-3xl shadow-2xl flex flex-col items-center animate-fade-in">
        <h1 className="text-4xl md:text-5xl font-extrabold mb-6 text-center text-transparent bg-clip-text bg-gradient-to-r from-pink-300 via-purple-300 to-indigo-300 tracking-tight leading-tight">
          AI Image Style Transformer
        </h1>
        <p className="text-lg text-center mb-10 max-w-2xl opacity-90">
          Upload your photo and let AI transform your style into three distinct, high-quality looks: Luxury, Streetwear, and Formal Professional. Your face stays the same, only the fashion changes!
        </p>

        {/* API Key Management Section */}
        <div className="mb-8 p-4 bg-gray-50 border border-gray-200 text-gray-800 rounded-lg max-w-lg w-full text-center shadow-inner">
            <h2 className="text-xl font-semibold mb-2">API Key Management</h2>
            {apiKeySelected === null && <p className="text-sm">Checking API Key status...</p>}
            {apiKeySelected !== null && (
                <p className="text-sm mb-3">
                    Status: <span className={`font-bold ${apiKeySelected ? 'text-green-600' : 'text-red-600'}`}>
                        {apiKeySelected ? 'Selected' : 'Not Selected'}
                    </span>
                </p>
            )}
            <button
                onClick={handleManageApiKey}
                className="bg-blue-600 hover:bg-blue-700 text-white font-bold py-2 px-4 rounded-full text-sm transition-all duration-200 disabled:opacity-50 disabled:cursor-not-allowed"
                disabled={isLoadingImages || isLoadingVideo || apiKeySelected === null}
            >
                {apiKeySelected ? 'Change API Key' : 'Select API Key'}
            </button>
            <p className="text-xs mt-3 text-gray-600">
                <a
                    href="https://ai.google.dev/gemini-api/docs/billing"
                    target="_blank"
                    rel="noopener noreferrer"
                    className="underline hover:text-blue-700"
                >
                    Learn about API billing
                </a>
            </p>
        </div>

        <ImageInput onImageSelected={handleImageSelected} isLoading={isLoadingImages || isLoadingVideo} />

        <div className="flex flex-col sm:flex-row gap-4 mt-8 w-full max-w-lg">
          <button
            onClick={handleGenerateImages}
            disabled={!uploadedImageBase64 || isLoadingImages || isLoadingVideo}
            className="flex-1 bg-indigo-600 hover:bg-indigo-700 text-white font-bold py-3 px-6 rounded-full text-lg shadow-lg transform transition-all duration-300 hover:scale-105 disabled:opacity-50 disabled:cursor-not-allowed flex items-center justify-center gap-2"
          >
            {isLoadingImages ? (
              <>
                <svg className="animate-spin h-5 w-5 text-white" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
                  <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle>
                  <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
                </svg>
                Generating Styles...
              </>
            ) : (
              'Generate Styles'
            )}
          </button>
          <button
            onClick={handleGenerateVideo}
            disabled={!uploadedImageBase64 || isLoadingVideo || isLoadingImages || !apiKeySelected}
            className="flex-1 bg-gradient-to-r from-red-500 to-orange-500 hover:from-red-600 hover:to-orange-600 text-white font-bold py-3 px-6 rounded-full text-lg shadow-lg transform transition-all duration-300 hover:scale-105 disabled:opacity-50 disabled:cursor-not-allowed flex items-center justify-center gap-2"
          >
            {isLoadingVideo ? (
              <>
                <svg className="animate-spin h-5 w-5 text-white" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
                  <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle>
                  <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
                </svg>
                Generating Video... This may take a few minutes.
              </>
            ) : (
              'Generate Video'
            )}
          </button>
        </div>

        {error && (
          <div className="mt-8 p-4 bg-red-100 border border-red-400 text-red-700 rounded-lg max-w-lg w-full text-center">
            <strong className="font-bold">Error:</strong> {error.message}
            {error.details && <p className="text-sm mt-1 whitespace-pre-wrap">{error.details}</p>}
          </div>
        )}

        {videoError && (
          <div className="mt-8 p-4 bg-red-100 border border-red-400 text-red-700 rounded-lg max-w-lg w-full text-center">
            <strong className="font-bold">Video Generation Error:</strong> {videoError.message}
            {videoError.details && <p className="text-sm mt-1 whitespace-pre-wrap">{videoError.details}</p>}
          </div>
        )}

        <GeneratedImageViewer images={generatedImages} />

        {generatedVideo && (
          <div className="mt-12 w-full max-w-xl bg-white rounded-xl shadow-xl overflow-hidden transform transition-transform duration-300 hover:scale-[1.02] flex flex-col items-center">
            <h2 className="text-2xl font-bold text-gray-800 p-4 border-b-2 border-indigo-200 w-full text-center">Generated Video</h2>
            <video
              src={generatedVideo.videoUrl}
              controls
              className="w-full h-auto object-contain bg-black"
              style={{ maxHeight: '500px' }} // Limit video height
            >
              Your browser does not support the video tag.
            </video>
            <p className="text-sm text-gray-600 p-4 text-center">{generatedVideo.prompt}</p>
          </div>
        )}
      </div>
    </div>
  );
};

export default App;